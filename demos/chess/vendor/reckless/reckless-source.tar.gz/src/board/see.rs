use crate::{
    lookup::{bishop_attacks, ray_pass, rook_attacks},
    types::{Bitboard, Color, Move, PieceType},
};

impl super::Board {
    /// Checks if the static exchange evaluation (SEE) of a move meets the given `threshold`,
    /// indicating that the sequence of captures on a single square, starting with the move,
    /// results in a value greater than or equal to the threshold for the side to move.
    ///
    /// Promotions and castling always pass this check.
    pub fn see(&self, mv: Move, threshold: i32) -> bool {
        if mv.is_castling() {
            return true;
        }

        // In the best case, we win a piece, but still end up with a negative balance
        let mut balance = self.move_value(mv) - threshold;
        if balance < 0 {
            return false;
        }

        // In the worst case, we lose a piece, but still end up with a non-negative balance
        balance -= self.piece_on(mv.from()).value();

        if let Some(promotion) = mv.promotion_piece() {
            balance -= promotion.value();
        }

        if balance >= 0 {
            return true;
        }

        let mut occupancies = self.occupancies();
        occupancies.clear(mv.from()); //Note: No need to set "to" square.

        if mv.is_en_passant() {
            occupancies.clear(mv.to() ^ 8);
        }

        let mut attackers = self.attackers_to(mv.to(), occupancies) & occupancies;
        let mut stm = !self.side_to_move();

        let diagonal = self.pieces(PieceType::Bishop) | self.pieces(PieceType::Queen);
        let orthogonal = self.pieces(PieceType::Rook) | self.pieces(PieceType::Queen);

        let king_rays =
            [ray_pass(self.king_square(Color::White), mv.to()), ray_pass(self.king_square(Color::Black), mv.to())];

        loop {
            let mut our_attackers = attackers & self.colors(stm);

            // Exclude pinned pieces if pinners are still on the board
            if (self.pinners(!stm) & occupancies) != Bitboard(0) {
                our_attackers &= !(self.pinned(stm) & !king_rays[stm]);
            }

            if our_attackers.is_empty() {
                break;
            }

            let attacker = self.least_valuable_attacker(our_attackers);

            // The king cannot capture a protected piece; the side to move loses the exchange
            if attacker == PieceType::King && !(attackers & self.colors(!stm)).is_empty() {
                break;
            }

            // Make the capture
            occupancies.clear((self.pieces(attacker) & our_attackers).lsb());
            stm = !stm;

            // Assume our piece is going to be captured
            balance = -balance - 1 - attacker.value();
            if balance >= 0 {
                break;
            }

            // Capturing a piece may reveal a new sliding attacker
            if [PieceType::Pawn, PieceType::Bishop, PieceType::Queen].contains(&attacker) {
                attackers |= bishop_attacks(mv.to(), occupancies) & diagonal;
            }
            if [PieceType::Rook, PieceType::Queen].contains(&attacker) {
                attackers |= rook_attacks(mv.to(), occupancies) & orthogonal;
            }
            attackers &= occupancies;
        }

        // The last side to move has failed to capture back
        // since it has no more attackers and, therefore, is losing
        stm != self.side_to_move()
    }

    fn move_value(&self, mv: Move) -> i32 {
        if mv.is_en_passant() {
            return PieceType::Pawn.value();
        }

        let capture = self.piece_on(mv.to()).piece_type();

        if let Some(promotion) = mv.promotion_piece() {
            capture.value() + promotion.value() - PieceType::Pawn.value()
        } else {
            capture.value()
        }
    }

    fn least_valuable_attacker(&self, attackers: Bitboard) -> PieceType {
        for index in 0..PieceType::NUM {
            let piece = PieceType::new(index);
            if !(self.pieces(piece) & attackers).is_empty() {
                return piece;
            }
        }
        unreachable!();
    }
}
