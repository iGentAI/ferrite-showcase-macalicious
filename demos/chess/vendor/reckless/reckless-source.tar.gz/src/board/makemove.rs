use super::{Board, BoardObserver};
use crate::types::{Bitboard, Move, MoveKind, Piece, PieceType, Square, ZOBRIST};

impl Board {
    pub fn make_null_move(&mut self) {
        self.side_to_move = !self.side_to_move;
        self.state_stack.push(self.state);

        self.state.key ^= ZOBRIST.side;
        self.state.key ^= ZOBRIST.castling[self.state.castling];
        self.state.plies_from_null = 0;
        self.state.repetition = 0;
        self.state.captured = None;
        self.state.recapture_square = Square::None;
        self.state.checkers = Bitboard::default();

        self.update_threats();
        self.update_king_threats();

        if self.state.en_passant != Square::None {
            self.state.key ^= ZOBRIST.en_passant[self.state.en_passant];
            self.state.en_passant = Square::None;
        }
    }

    pub fn undo_null_move(&mut self) {
        self.side_to_move = !self.side_to_move;
        self.state = self.state_stack.pop().unwrap();
    }

    /// Plays a move on the board and pushes the previous state onto the stack.
    ///
    /// This method assumes the move has been validated as pseudo-legal and legal
    /// per `Board::is_pseudo_legal` and `Board::is_legal`.
    pub fn make_move<T: BoardObserver>(&mut self, mv: Move, observer: &mut T) {
        let from = mv.from();
        let to = mv.to();
        let piece = self.piece_on(from);
        let pt = piece.piece_type();
        let stm = self.side_to_move;

        self.state_stack.push(self.state);

        self.state.key ^= ZOBRIST.castling[self.state.castling];
        self.state.key ^= ZOBRIST.side;

        if self.state.en_passant != Square::None {
            self.state.key ^= ZOBRIST.en_passant[self.state.en_passant];
            self.state.en_passant = Square::None;
        }

        self.state.captured = None;
        self.state.recapture_square = Square::None;

        if mv.kind() == MoveKind::Capture || pt == PieceType::Pawn {
            self.state.halfmove_clock = 0;
        } else {
            self.state.halfmove_clock += 1;
        }
        self.state.plies_from_null += 1;

        let captured = self.piece_on(to);
        if captured != Piece::None && !mv.is_castling() {
            self.remove_piece(piece, from);
            observer.on_piece_change(self, piece, from, false);

            self.remove_piece(captured, to);
            self.add_piece(piece, to);
            observer.on_piece_mutate(self, captured, piece, to);

            self.update_hash(captured, to);

            self.state.material -= captured.value();
            self.state.captured = Some(captured);
            self.state.recapture_square = to;
        } else if !mv.is_castling() {
            self.remove_piece(piece, from);
            self.add_piece(piece, to);
            observer.on_piece_move(self, piece, from, to);
        }

        self.update_hash(piece, from);
        self.update_hash(piece, to);

        match mv.kind() {
            MoveKind::DoublePush => {
                self.state.en_passant = Square::new((from as u8 + to as u8) / 2);
                self.state.key ^= ZOBRIST.en_passant[self.state.en_passant];
            }
            MoveKind::EnPassant => {
                let captured = Piece::new(!stm, PieceType::Pawn);

                self.remove_piece(captured, to ^ 8);
                observer.on_piece_change(self, captured, to ^ 8, false);

                self.update_hash(captured, to ^ 8);

                self.state.material -= captured.value();
            }
            MoveKind::Castling => {
                let (rook_from, rook_to) = self.get_castling_rook(to);
                let rook = Piece::new(stm, PieceType::Rook);

                self.remove_piece(rook, rook_from);
                observer.on_piece_change(self, rook, rook_from, false);

                self.remove_piece(piece, from);
                observer.on_piece_change(self, piece, from, false);

                self.add_piece(rook, rook_to);
                observer.on_piece_change(self, rook, rook_to, true);

                self.add_piece(piece, to);
                observer.on_piece_change(self, piece, to, true);

                self.update_hash(rook, rook_from);
                self.update_hash(rook, rook_to);
            }
            _ if mv.is_promotion() => {
                let promotion = Piece::new(stm, mv.promotion_piece().unwrap());

                self.remove_piece(piece, to);
                observer.on_piece_change(self, piece, to, false);

                self.add_piece(promotion, to);
                observer.on_piece_change(self, promotion, to, true);

                self.update_hash(piece, to);
                self.update_hash(promotion, to);

                self.state.material += promotion.value() - PieceType::Pawn.value();
            }
            _ => (),
        }

        self.side_to_move = !self.side_to_move;

        self.state.castling.raw &= self.castling_rights[from] & self.castling_rights[to];
        self.state.key ^= ZOBRIST.castling[self.state.castling];

        self.update_threats();
        self.update_king_threats();

        self.state.repetition = 0;

        let end = self.state.plies_from_null.min(self.state.halfmove_clock as usize);

        if end >= 4 {
            let mut idx = self.state_stack.len() as isize - 4;
            for i in (4..=end).step_by(2) {
                if idx < 0 {
                    break;
                }

                let stp = &self.state_stack[idx as usize];

                if stp.key == self.state.key {
                    self.state.repetition = if stp.repetition != 0 { -(i as i32) } else { i as i32 };
                    break;
                }

                idx -= 2;
            }
        }
    }

    pub fn undo_move(&mut self, mv: Move) {
        self.side_to_move = !self.side_to_move;

        let from = mv.from();
        let to = mv.to();
        let piece = self.piece_on(to);
        let stm = self.side_to_move;

        if !mv.is_castling() {
            self.add_piece(piece, from);
            self.remove_piece(piece, to);
        }

        if let Some(piece) = self.state.captured {
            self.add_piece(piece, to);
        }

        match mv.kind() {
            MoveKind::EnPassant => {
                self.add_piece(Piece::new(!stm, PieceType::Pawn), to ^ 8);
            }
            MoveKind::Castling => {
                let (rook_from, rook_to) = self.get_castling_rook(to);

                self.remove_piece(Piece::new(stm, PieceType::Rook), rook_to);
                self.remove_piece(piece, to);

                self.add_piece(Piece::new(stm, PieceType::Rook), rook_from);
                self.add_piece(piece, from);
            }
            _ if mv.is_promotion() => {
                self.remove_piece(piece, from);
                self.add_piece(Piece::new(stm, PieceType::Pawn), from);
            }
            _ => (),
        }

        self.state = self.state_stack.pop().unwrap();
    }
}
