use crate::{
    lookup::{between, bishop_attacks, king_attacks, knight_attacks, pawn_attacks, queen_attacks, rook_attacks},
    types::{Bitboard, CastlingKind, Color, File, MoveKind, MoveList, PieceType, Rank, Square},
};

#[derive(Eq, PartialEq)]
enum Kind {
    Quiet,
    Noisy,
}

trait MoveGenerator {
    const KIND: Kind;
}

struct Quiet;
impl MoveGenerator for Quiet {
    const KIND: Kind = Kind::Quiet;
}

struct Noisy;
impl MoveGenerator for Noisy {
    const KIND: Kind = Kind::Noisy;
}

impl super::Board {
    pub fn has_legal_moves(&self) -> bool {
        let mut list = MoveList::new();
        self.append_all_moves(&mut list);
        list.iter().any(|entry| self.is_legal(entry.mv))
    }

    pub fn generate_all_moves(&self) -> MoveList {
        let mut list = MoveList::new();
        self.append_all_moves(&mut list);
        list
    }

    pub fn append_all_moves(&self, list: &mut MoveList) {
        self.append_noisy_moves(list);
        self.append_quiet_moves(list);
    }

    pub fn append_quiet_moves(&self, list: &mut MoveList) {
        self.generate_moves::<Quiet>(list);
    }

    pub fn append_noisy_moves(&self, list: &mut MoveList) {
        self.generate_moves::<Noisy>(list);
    }

    fn generate_moves<T: MoveGenerator>(&self, list: &mut MoveList) {
        self.collect_for::<T, _>(list, Bitboard::ALL, PieceType::King, king_attacks);

        if self.checkers().is_multiple() {
            return;
        }

        let occupancies = self.occupancies();
        let target = if self.in_check() {
            between(self.king_square(self.side_to_move), self.checkers().lsb()) | self.checkers().lsb().to_bb()
        } else {
            Bitboard::ALL
        };

        self.collect_pawn_moves::<T>(list);

        self.collect_for::<T, _>(list, target, PieceType::Knight, knight_attacks);
        self.collect_for::<T, _>(list, target, PieceType::Bishop, |square| bishop_attacks(square, occupancies));
        self.collect_for::<T, _>(list, target, PieceType::Rook, |square| rook_attacks(square, occupancies));
        self.collect_for::<T, _>(list, target, PieceType::Queen, |square| queen_attacks(square, occupancies));

        if T::KIND == Kind::Quiet {
            self.collect_castling(list);
        }
    }

    fn collect_for<T: MoveGenerator, F: Fn(Square) -> Bitboard>(
        &self, list: &mut MoveList, target: Bitboard, piece: PieceType, attacks: F,
    ) {
        for from in self.our(piece) {
            if T::KIND == Kind::Noisy {
                list.push_setwise(from, attacks(from) & target & self.them(), MoveKind::Capture);
            }

            if T::KIND == Kind::Quiet {
                list.push_setwise(from, attacks(from) & target & !self.occupancies(), MoveKind::Normal);
            }
        }
    }

    fn collect_castling(&self, list: &mut MoveList) {
        match self.side_to_move {
            Color::White => {
                self.collect_castling_kind(list, CastlingKind::WhiteKingside);
                self.collect_castling_kind(list, CastlingKind::WhiteQueenside);
            }
            Color::Black => {
                self.collect_castling_kind(list, CastlingKind::BlackKingside);
                self.collect_castling_kind(list, CastlingKind::BlackQueenside);
            }
        }
    }

    fn collect_castling_kind(&self, list: &mut MoveList, kind: CastlingKind) {
        if self.castling().is_allowed(kind)
            && (self.castling_path[kind] & self.occupancies()).is_empty()
            && (self.castling_threat[kind] & self.threats()).is_empty()
        {
            let king = self.king_square(self.side_to_move);
            list.push(king, kind.landing_square(), MoveKind::Castling);
        }
    }

    fn collect_pawn_moves<T: MoveGenerator>(&self, list: &mut MoveList) {
        let pawns = self.our(PieceType::Pawn);
        let seventh_rank = match self.side_to_move {
            Color::White => Bitboard::rank(Rank::R7),
            Color::Black => Bitboard::rank(Rank::R2),
        };

        self.collect_pawn_pushes::<T>(list, pawns, seventh_rank);

        if T::KIND == Kind::Noisy {
            self.collect_pawn_captures(list, pawns, seventh_rank);
            self.collect_en_passant_moves(list, pawns);
        }
    }

    fn collect_pawn_pushes<T: MoveGenerator>(&self, list: &mut MoveList, pawns: Bitboard, seventh_rank: Bitboard) {
        let (up, third_rank) = match self.side_to_move {
            Color::White => (8, Bitboard::rank(Rank::R3)),
            Color::Black => (-8, Bitboard::rank(Rank::R6)),
        };

        let empty = !self.occupancies();

        if T::KIND == Kind::Quiet {
            let non_promotions = pawns & !seventh_rank;
            let single_pushes = non_promotions.shift(up) & empty;
            let double_pushes = (single_pushes & third_rank).shift(up) & empty;

            list.push_pawns_setwise(up, single_pushes, MoveKind::Normal);
            list.push_pawns_setwise(up * 2, double_pushes, MoveKind::DoublePush);
        }

        let promotions = (pawns & seventh_rank).shift(up) & empty;
        if T::KIND == Kind::Noisy {
            list.push_pawns_setwise(up, promotions, MoveKind::PromotionQ);
        }
        if T::KIND == Kind::Quiet {
            list.push_pawns_setwise(up, promotions, MoveKind::PromotionR);
            list.push_pawns_setwise(up, promotions, MoveKind::PromotionB);
            list.push_pawns_setwise(up, promotions, MoveKind::PromotionN);
        }
    }

    fn collect_pawn_captures(&self, list: &mut MoveList, pawns: Bitboard, seventh_rank: Bitboard) {
        let (up_right, up_left) = match self.side_to_move {
            Color::White => (9, 7),
            Color::Black => (-7, -9),
        };

        let promotions = pawns & seventh_rank;
        let right = (promotions & !Bitboard::file(File::H)).shift(up_right) & self.them();
        let left = (promotions & !Bitboard::file(File::A)).shift(up_left) & self.them();

        list.push_promotion_capture_setwise(up_right, right);
        list.push_promotion_capture_setwise(up_left, left);

        let non_promotions = pawns & !seventh_rank;
        let right_captures = (non_promotions & !Bitboard::file(File::H)).shift(up_right) & self.them();
        let left_captures = (non_promotions & !Bitboard::file(File::A)).shift(up_left) & self.them();

        list.push_pawns_setwise(up_right, right_captures, MoveKind::Capture);
        list.push_pawns_setwise(up_left, left_captures, MoveKind::Capture);
    }

    fn collect_en_passant_moves(&self, list: &mut MoveList, pawns: Bitboard) {
        if self.state.en_passant != Square::None {
            let pawns = pawns & pawn_attacks(self.state.en_passant, !self.side_to_move);
            for pawn in pawns {
                list.push(pawn, self.state.en_passant, MoveKind::EnPassant);
            }
        }
    }
}
